package com.r3sys.project;

public class Mail 
{
	 static String email;
	 public static String getEmail() 
	    {
			return email;
		}

		public static void setEmail(String email) 
		{
			Mail.email = email;
        }
}